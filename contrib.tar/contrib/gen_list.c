const char gen_list_rcs[] = "$Id$";
/*********************************************************************
 *
 * File        :  $Source$
 *
 * Purpose     :  To create some functions to do generic doubly linked
 *						list management.
 *
 * Copyright   :  Written by and Copyright (C) 2001 the SourceForge
 *                IJBSWA team.  http://ijbswa.sourceforge.net
 *
 *                This program is free software; you can redistribute it
 *                and/or modify it under the terms of the GNU General
 *                Public License as published by the Free Software
 *                Foundation; either version 2 of the License, or (at
 *                your option) any later version.
 *
 *                This program is distributed in the hope that it will
 *                be useful, but WITHOUT ANY WARRANTY; without even the
 *                implied warranty of MERCHANTABILITY or FITNESS FOR A
 *                PARTICULAR PURPOSE.  See the GNU General Public
 *                License for more details.
 *
 *                The GNU General Public License should be included with
 *                this file.  If not, you can view it at
 *                http://www.gnu.org/copyleft/gpl.html
 *                or write to the Free Software Foundation, Inc., 59
 *                Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * VI users		:	Please "set tabstop=3 shiftwidth=3" to view this file,
 *						and edit IJB, correctly.
 *
 * Revisions   :
 *    $Log$
 *    Revision 1.1  2001/12/04 01:24:58  iwanttokeepanon
 *    This list supports:
 *    	copy construction,
 *    	"virtual" destruction,
 *    	streaming,
 *    	comparison (equal comparison currently supported).
 *
 *    With the "object oriented" nature of the list, nodes, and records; it is
 *    easily concievable that sorted lists and hash tables could be implemented
 *    with little extra effort.
 *
 *
 *    Philosophical point:
 *
 *    I am sure there is room for improvement with this design.  I am
 *    submitting this as a generic doubly linked list recomendation for IJB.
 *    Whatever the "collective" decides is fine with me.
 *
 *    This implementation uses the "naming space" of gen_list, derived_rec,
 *    construct, copy construct, stream, destruct, etc...  These are open to
 *    argument.  I just used what was familiar to me and others in the "OO"
 *    community.  If these need changed to be adopted ... "so be it".
 *
 *
 *    Implementation point:
 *
 *    I assume this is too late for a "3.0" release.  As I work for an
 *    airline, the whole past summer has been hectic (not to mention the
 *    last 4 months); but things have begun to settle down and I am
 *    following the IJB lists a bit more closely.  And I would like to say
 *    "HOLY CRAP!" .. you guys have accompolished a lot!  Way to go.
 *
 *    But, the adoption of a better linked list package should at least be
 *    high on the next release list (if not the current one).  If you choose
 *    this submission or not, so be it.  But as a "data structure" man, I
 *    think IJB's linked lists need addressing.
 *
 *
 *    List/Enlist note:
 *
 *    I have noticed the list.c file.  If this generic list is adopted, I
 *    think all existing functionallity could be duplicated with the
 *    "copy_contruct", "equal", and "destruct" `virtuals'.  This would also
 *    eliminate and/or enhance the other manually maintained lists in IJB.
 *
 *
 *    Debug note:
 *
 *    Since the generic list defined a "stream" virtual, it could be programmed
 *    that the list could print itself whenever a FATAL error occurs.  A user (or
 *    programmer) could read the list and hopefully determine the cause of the
 *    abend.
 *
 *
 *    Potential note:
 *
 *    Think of the possibilites of a linked list, sorted list, and/or a hash
 *    list.  Think of a request to a web site that has been referenced
 *    before.  If a hash list keep track of all block requests and regexp
 *    change commands, then a site could be blocked and/or modified without
 *    ever consulting the actions lists again.  What a speed up!
 *
 *    What if some of the current lists were kept in sorted lists?  Then a
 *    search for a particular record could be a binary search instead of a
 *    linear search.
 *
 *    The actions file(s) and regexp files(s) could be inserted into the
 *    list from front to back order (or visa versa) and the processing would
 *    take place in actual file order (which is more natural); rather than
 *    in reverse order (as it is today).
 *
 *
 *    Thank you for you time and attention to this contribution.  If it is
 *    "blessed" by the group, I am available to give time to integrating
 *    this into IJB.
 *
 *    Let me know what y'all think about this package.
 *
 *    --
 *    Rodney
 *
 *
 *********************************************************************/


#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "gen_list.h"
#include "malloc_police.h"

const char gen_list_h_rcs[] = GEN_LIST_H_VERSION;


/* This is used (for the moment) to cut out all the	*/
/* extra verbige of the malloc_police module.  After	*/
/* all, we do not want to see construct/destruct of a	*/
/* class that is supposed to be "in the background".	*/

/* But it could lead to broader usage.						*/

int list_is_quiet = 0;


#define CALL_VT_REC_COPY_CONSTRUCT(rec)	(((rec_copy_construct)(rec)->vtable[ VT_REC_COPY_CONSTRUCT ])( rec ))
#define CALL_VT_REC_DESTRUCT(rec)			(((rec_destruct)(rec)->vtable[ VT_REC_DESTRUCT ])( rec ))
#define CALL_VT_REC_STREAM(rec)				(((rec_stream)(rec)->vtable[ VT_REC_STREAM ])( rec ))
#define CALL_VT_REC_EQUAL(rec,eq_rec)		(((rec_equal)((rec)->vtable[ VT_REC_EQUAL ]))( rec, eq_rec ))


/*********************************************************************
 *
 * Function    :  gen_list_rec_construct
 *
 * Description :  Called from a derived list record class ONLY.
 *						This function "construct" a classs: malloc_ed,
 *						vtable, isa, and sizeof_rec "attributes".
 *
 * Parameters  :
 *          1  :  The record.  If NULL, malloc is called.
 *				2	:	isa (prounced "is a") ... type of the record.
 *				3	:	Memory image size of this record.
 *			 ...	:	The "virtuals" for this record.  NOTE: this list
 *						may increase if more "virtuals" are added.
 *
 * Returns     :  A pointer to the record (either the orig record
 *						or the malloc_ed copy.
 *
 *********************************************************************/
struct gen_list_rec *gen_list_rec_construct( enum GEN_LIST_ISA isa, int sizeof_rec, const t_vtable _vtable )
{
	struct gen_list_rec *this_rec = (struct gen_list_rec *)MALLOC( sizeof_rec );
	this_rec->vtable		= _vtable;
	this_rec->isa			= isa;
	this_rec->sizeof_rec	= sizeof_rec;

	return( this_rec );

}


/*********************************************************************
 *
 * Function    :  gen_list_rec_copy_construct
 *
 * Description :  Makes a copy of the current existing record.  All
 *						inherited properties (isa, vtable, malloc_ed, ...)
 *						are kept in tact after the copy.
 *
 * Parameters  :
 *          1  :  Existing record.
 *				2	:  New record.
 *
 * Returns     :  The newly constructed copy record.
 *
 *********************************************************************/
struct gen_list_rec *gen_list_rec_copy_construct( const struct gen_list_rec *this_rec )
{
	struct gen_list_rec *copy_rec = (struct gen_list_rec *)MALLOC( this_rec->sizeof_rec );
	copy_rec->vtable		= this_rec->vtable;
	copy_rec->isa			= this_rec->isa;
	copy_rec->sizeof_rec	= this_rec->sizeof_rec;

	return( copy_rec );

}


/*********************************************************************
 *
 * Function    :  gen_list_rec_destruct
 *
 * Description :  Destruct the record.  Including free_ing the memory
 *						if applicable.
 *
 * Parameters  :
 *          1  :  The record.
 *
 * Returns     :  NULL
 *
 *********************************************************************/
struct gen_list_rec *gen_list_rec_destruct( struct gen_list_rec *this_rec )
{
	FREE( this_rec );
	return( NULL );

}


/*********************************************************************
 *
 * Function    :  gen_list_rec_stream
 *
 * Description :  Displays all attributes on the STDOUT stream.
 *
 * Parameters  :
 *          1  :  The record.
 *
 * Returns     :  The record.
 *
 *********************************************************************/
const struct gen_list_rec *gen_list_rec_stream( const struct gen_list_rec *this_rec )
{
	LIST_SHOW( printf( "\t\tstream rec isa = %s\n", isa_ra[ this_rec->isa ] ) );
	return( this_rec );

}


/*********************************************************************
 *
 * Function    :  gen_list_rec_equal
 *
 * Description :  Compares two records to see if they are equal.
 *
 * Parameters  :
 *          1  :  A record.
 *          2  :  Another record.
 *
 * Returns     :  0 => NOT EQUAL, anything else is EQUAL.
 *
 *********************************************************************/
int gen_list_rec_equal( const struct gen_list_rec *this_rec, const struct gen_list_rec *eq_rec )
{
	if ( NULL == this_rec && NULL == eq_rec )
	{
		return( 1 );
	}

	if (	( NULL == this_rec && NULL != eq_rec )	||
			( NULL != this_rec && NULL == eq_rec ) )
	{
		return( 0 );
	}

	if (	( this_rec->isa != eq_rec->isa ) ||
			( this_rec->sizeof_rec != eq_rec->sizeof_rec ) )
	{
		LIST_SHOW( printf( "INFORMATION: sorry, but comparing different rec types is unsupported at this time.\n" ) );
		return( 0 );
	}

	return( 1 );

}


/**********************************************************************/


struct gen_list_node
{
	/* private: */
	struct gen_list_node	*next;
	struct gen_list_node	*prev;

	struct gen_list_rec	*rec;
};
/* public: */
extern struct gen_list_node *			gen_list_node_construct( struct gen_list_rec *_rec );
extern struct gen_list_node *			gen_list_node_copy_construct( const struct gen_list_node *this_node );
extern struct gen_list_node *			gen_list_node_destruct( struct gen_list_node *this_node );
extern struct gen_list_node *			gen_list_node_remove( struct gen_list_node *this_node );

extern struct gen_list_node *			gen_list_node_set_next( struct gen_list_node *this_node, struct gen_list_node *_next );
extern struct gen_list_node *			gen_list_node_set_prev( struct gen_list_node *this_node, struct gen_list_node *_prev );

extern struct gen_list_node *			gen_list_node_get_next( const struct gen_list_node *this_node );
extern struct gen_list_node *			gen_list_node_get_prev( const struct gen_list_node *this_node );

extern const struct gen_list_rec	*	gen_list_node_stream( const struct gen_list_node *this_node );
extern int									gen_list_node_equal( const struct gen_list_node *this_node, const struct gen_list_node *eq_node );

/* struct/class COMPLETE */


/*********************************************************************
 *
 * Function    :  gen_list_node_construct
 *
 * Description :  Constructs a generic list node and sets its record.
 *
 * Parameters  :
 *          1  :  The node.  If NULL, malloc is called.
 *          2  :  The nodes record contents.
 *
 * Returns     :  A pointer to the node (either the orig node
 *						or the malloc_ed copy.
 *
 *********************************************************************/
struct gen_list_node *gen_list_node_construct( struct gen_list_rec *_rec )
{
	struct gen_list_node *this_node = (struct gen_list_node *)MALLOC( sizeof( struct gen_list_node ) );

	LIST_SHOW( printf( "\
\tconstruct new node\t\t= %p
\tconstruct new node->rec\t= %p\n\n", (const void *)this_node, (const void *)_rec ) );

	this_node->rec		= _rec;
	this_node->next	= NULL;
	this_node->prev	= NULL;

	return( this_node );

}


/*********************************************************************
 *
 * Function    :  gen_list_node_copy_construct
 *
 * Description :  Makes a copy of the current node.
 *
 * Parameters  :
 *          1  :  Existing node.
 *				2	:  New node.
 *
 * Returns     :  The newly constructed copy node.
 *
 *********************************************************************/
struct gen_list_node *gen_list_node_copy_construct( const struct gen_list_node *this_node )
{
	struct gen_list_node *copy_node = (struct gen_list_node *)MALLOC( sizeof( struct gen_list_node ) );

	LIST_SHOW( printf( "\tcopy construct new node = %p => %p\n\n", (const void *)this_node, (const void *)copy_node ) );

	copy_node->rec		= CALL_VT_REC_COPY_CONSTRUCT( this_node->rec );
	copy_node->next	= NULL;
	copy_node->prev	= NULL;

	return( copy_node );

}


/*********************************************************************
 *
 * Function    :  gen_list_node_destruct
 *
 * Description :  Destruct the node.  Including free_ing the memory
 *						if applicable.
 *
 * Parameters  :
 *          1  :  The node.
 *
 * Returns     :  NULL
 *
 *********************************************************************/
struct gen_list_node *gen_list_node_destruct( struct gen_list_node *this_node )
{
	LIST_SHOW( printf( "\
\tdestruct this_node\t\t\t= %p
\tdestruct this_node->rec\t\t= %p
\tdestruct this_node->next\t= %p
\tdestruct this_node->prev\t= %p\n\n", (const void *)this_node, (const void *)this_node->rec, (const void *)this_node->next, (const void *)this_node->prev ) );

	if ( NULL != this_node->rec )
	{
		CALL_VT_REC_DESTRUCT( this_node->rec );
	}

	FREE( this_node );
	return( NULL );

}


/*********************************************************************
 *
 * Function    :  gen_list_node_remove
 *
 * Description :  Destruct the node.  Including free_ing the memory
 *						if applicable.
 *
 * Parameters  :
 *          1  :  The node.
 *
 * Returns     :  NULL
 *
 *********************************************************************/
struct gen_list_node *gen_list_node_remove( struct gen_list_node *this_node )
{
	LIST_SHOW( printf( "\
\tremove this_node\t\t\t= %p
\tremove this_node->rec\t= %p
\tremove this_node->next\t= %p
\tremove this_node->prev\t= %p\n\n", (const void *)this_node, (const void *)this_node->rec, (const void *)this_node->next, (const void *)this_node->prev ) );

	FREE( this_node );
	return( NULL );

}


/*********************************************************************
 *
 * Function    :  gen_list_node_set_next
 *
 * Description :  Sets the next node in the list series.  Used mainly
 *						when constructing and adding/removing nodes.
 *
 * Parameters  :
 *          1  :  The node.
 *          2  :  The next node.
 *
 * Returns     :  The node.
 *
 *********************************************************************/
struct gen_list_node *gen_list_node_set_next( struct gen_list_node *this_node, struct gen_list_node *_next )
{
	this_node->next = _next;
	return( this_node );

}


/*********************************************************************
 *
 * Function    :  gen_list_node_set_prev
 *
 * Description :  Sets the previous node in the list series.  Used mainly
 *						when constructing and adding/removing nodes.
 *
 * Parameters  :
 *          1  :  The node.
 *          2  :  The previous node.
 *
 * Returns     :  The node.
 *
 *********************************************************************/
struct gen_list_node *gen_list_node_set_prev( struct gen_list_node *this_node, struct gen_list_node *_prev )
{
	this_node->prev = _prev;
	return( this_node );

}


/*********************************************************************
 *
 * Function    :  gen_list_node_get_next
 *
 * Description :  Gets the next node in the list series.  Used mainly
 *						for traversing a list.
 *
 * Parameters  :
 *          1  :  The node.
 *
 * Returns     :  The next node.
 *
 *********************************************************************/
struct gen_list_node *gen_list_node_get_next( const struct gen_list_node *this_node )
{
	return( this_node->next );

}


/*********************************************************************
 *
 * Function    :  gen_list_node_get_prev
 *
 * Description :  Gets the previous node in the list series.  Used mainly
 *						for traversing a list.
 *
 * Parameters  :
 *          1  :  The node.
 *
 * Returns     :  The previous node.
 *
 *********************************************************************/
struct gen_list_node *gen_list_node_get_prev( const struct gen_list_node *this_node )
{
	return( this_node->prev );

}


/*********************************************************************
 *
 * Function    :  gen_list_node_stream
 *
 * Description :  Displays all attributes on the STDOUT stream,
 *						including the contents of the nodes record.
 *
 * Parameters  :
 *          1  :  The record.
 *
 * Returns     :  The result of streaming the nodes record.
 *
 *********************************************************************/
const struct gen_list_rec *gen_list_node_stream( const struct gen_list_node *this_node )
{
	LIST_SHOW( printf( "\
\tstream this_node\t\t\t= %p
\tstream this_node->rec\t= %p
\tstream this_node->next\t= %p
\tstream this_node->prev\t= %p\n\n", (const void *)this_node, (const void *)this_node->rec, (const void *)this_node->next, (const void *)this_node->prev ) );

	return( CALL_VT_REC_STREAM( this_node->rec ) );

}


/*********************************************************************
 *
 * Function    :  gen_list_node_equal
 *
 * Description :  Compares two nodes (and their records) to see if they are equal.
 *
 * Parameters  :
 *          1  :  A node.
 *          2  :  Another node.
 *
 * Returns     :  0 => NOT EQUAL, anything else is EQUAL.
 *
 *********************************************************************/
int gen_list_node_equal( const struct gen_list_node *this_node, const struct gen_list_node *eq_node )
{
	if ( NULL == this_node && NULL == eq_node )
	{
		return( 1 );
	}

	if (	( NULL == this_node && NULL != eq_node ) ||
			( NULL != this_node && NULL == eq_node ) )
	{
		return( 0 );
	}

	return( gen_list_rec_equal( this_node->rec, eq_node->rec ) );

}


/**********************************************************************/


/* private: */
/*********************************************************************
 *
 * Function    :  gen_list_insert_node
 *
 * Description :  Inserts a node (not a record!) into a list.  This
 *						is (currently) only used in copy construction.
 *
 * Parameters  :
 *          1  :  The list.
 *          2  :  A new node to insert into the list.
 *
 * Returns     :  The node.
 *
 *********************************************************************/
const struct gen_list_node *gen_list_insert_node( struct gen_list *this_list, struct gen_list_node *node )
{
	gen_list_node_set_next( node, NULL );

	if ( NULL == this_list->first )
	{
		this_list->first = node;
	}

	if ( NULL == this_list->last )
	{
		this_list->last = node;
	}
	else
	{
		gen_list_node_set_next( this_list->last, node );
		gen_list_node_set_prev( node, this_list->last );
		this_list->last = node;
	}

	this_list->last = node;

	return( node );

}


/*********************************************************************
 *
 * Function    :  gen_list_construct
 *
 * Description :  Constructs a generic list.
 *
 * Parameters  :	None
 *
 * Returns     :  A pointer to the list (either the orig list
 *						or the malloc_ed copy.
 *
 *********************************************************************/
struct gen_list *gen_list_construct()
{
	struct gen_list *this_list = (struct gen_list *)MALLOC( sizeof( struct gen_list ) );
	LIST_SHOW( printf( "construct new list = %p\n\n", (const void *)this_list ) );

	this_list->first	= NULL;
	this_list->last	= NULL;

	return( this_list );

}


/*********************************************************************
 *
 * Function    :  gen_list_copy_construct
 *
 * Description :  Makes a copy of the current list.
 *
 * Parameters  :
 *          1  :  Existing list.
 *				2	:  New list.
 *
 * Returns     :  The newly constructed copy list.
 *
 *********************************************************************/
struct gen_list *gen_list_copy_construct( const struct gen_list *this_list )
{
	struct gen_list_node *curr = this_list->first;
	struct gen_list *copy_list = (struct gen_list *)MALLOC( sizeof( struct gen_list ) );

	LIST_SHOW( printf( "copy construct new list = %p => %p\n\n", (const void *)this_list, (const void *)copy_list ) );

	copy_list->first	= NULL;
	copy_list->last	= NULL;


	while ( NULL != curr )
	{
		struct gen_list_node *copy_node = gen_list_node_copy_construct( curr );
		gen_list_insert_node( copy_list, copy_node );
		curr = gen_list_node_get_next( curr );
	}

	return( copy_list );

}


/*********************************************************************
 *
 * Function    :  gen_list_destruct
 *
 * Description :  Destruct the list.  Including free_ing the memory
 *						if applicable.
 *
 * Parameters  :
 *          1  :  The list.
 *
 * Returns     :  NULL
 *
 *********************************************************************/
struct gen_list *gen_list_destruct( struct gen_list *this_list )
{
	struct gen_list_node *curr = this_list->first;

	LIST_SHOW( printf( "\
destruct this_list\t\t\t= %p
destruct this_list->first\t= %p
destruct this_list->last\t= %p\n\n", (const void *)this_list, (const void *)this_list->first, (const void *)this_list->last ) );

	while ( NULL != curr )
	{
		struct gen_list_node *next = gen_list_node_get_next( curr );
		gen_list_node_destruct( curr );
		curr = next;
	}

	FREE( this_list );
	return( NULL );

}


/*********************************************************************
 *
 * Function    :  gen_list_remove_all
 *
 * Description :  Destruct the list.  Including free_ing the memory
 *						if applicable.
 *
 * Parameters  :
 *          1  :  The list.
 *
 * Returns     :  NULL
 *
 *********************************************************************/
struct gen_list *gen_list_remove_all( struct gen_list *this_list )
{
	struct gen_list_node *curr = this_list->first;

	LIST_SHOW( printf( "\
remove_all this_list\t\t\t\t= %p
remove_all this_list->first\t= %p
remove_all this_list->last\t\t= %p\n\n", (const void *)this_list, (const void *)this_list->first, (const void *)this_list->last ) );

	while ( NULL != curr )
	{
		struct gen_list_node *next = gen_list_node_get_next( curr );
		gen_list_node_remove( curr );
		curr = next;
	}

	this_list->first = this_list->last = NULL;
	return( this_list );

}


/*********************************************************************
 *
 * Function    :  gen_list_remove
 *
 * Description :  A record from the list and return it if found.  This
 *						will allow a futher call to rec_destruct.
 *
 * Parameters  :
 *          1  :  The list.
 *          2  :  The record to be removed.
 *
 * Returns     :  rec if found and removed, NULL otherwise.
 *
 *********************************************************************/
struct gen_list_rec *gen_list_remove( struct gen_list *this_list, struct gen_list_rec *rec )
{
	struct gen_list_node	*curr = this_list->first;

	LIST_SHOW( printf( "\
remove this_list\t\t\t= %p
remove this_list->first\t= %p
remove this_list->last\t= %p
remove rec\t\t\t\t\t= %p\n\n", (const void *)this_list, (const void *)this_list->first, (const void *)this_list->last, rec ) );

	while ( NULL != curr )
	{
		/* Grab these values before the are destroyed. */
		struct gen_list_node	*prev = gen_list_node_get_prev( curr );
		struct gen_list_node	*next = gen_list_node_get_next( curr );

		/* Access to rec, next, prev of gen_list_node is allowed since it is private to gen_list */
		if ( curr->rec == rec )
		{
			/* Destruct the node, but not the record. */
			gen_list_node_remove( curr );

			if ( NULL == prev )
			{
				/************************************************/
				/* This is the first node in the list.				*/
				/* 	Picture:												*/
				/* [first] ---------------------> [next]			*/
				/* [NULL] <---------------------- [next->prev]	*/
				/************************************************/
				this_list->first = next;

				if ( NULL == next )
				{
					/* Since next is NULL, then this is an empty list. */
					this_list->last = NULL;
				}
				else
				{
					/* Since next is not NULL, then there is another node to make first. */
					gen_list_node_set_prev( next, NULL );
				}
			}
			else if ( NULL == next )
			{
				/************************************************/
				/* This is the last node in the list.				*/
				/* 	Picture:												*/
				/* [last] ----------------------> [prev]			*/
				/* [prev->next] ----------------> [NULL]			*/
				/************************************************/
				this_list->last = prev;

				if ( NULL == prev )
				{
					/* Since prev is NULL, then this is an empty list. */
					this_list->first = NULL;
				}
				else
				{
					/* Since prev is NULL, then there is another node to make last. */
					gen_list_node_set_next( prev, NULL );
				}
			}
			else
			{
				/************************************************/
				/* This is a middle node in the list.				*/
				/* 	Picture:												*/
				/* [prev->next] ----------------> [next]			*/
				/*					[removing middle]						*/
				/* [prev] <---------------------- [next->prev]	*/
				/************************************************/
				gen_list_node_set_next( prev, next );
				gen_list_node_set_prev( next, prev );
			}

			return( rec );
		}
		curr = next;
	}

	return( NULL );

}


/*********************************************************************
 *
 * Function    :  gen_list_get_first
 *
 * Description :  Gets the first record in the list.
 *
 * Parameters  :
 *          1  :  The list.
 *
 * Returns     :  The first node.
 *
 *********************************************************************/
struct gen_list_rec *gen_list_get_first( const struct gen_list *this_list )
{
	if ( NULL == this_list->first )
	{
		return( NULL );
	}

	/* Access to rec of gen_list_node is allowed since it is private to gen_list */
	return( this_list->first->rec );

}


/*********************************************************************
 *
 * Function    :  gen_list_get_last
 *
 * Description :  Gets the last record in the list.
 *
 * Parameters  :
 *          1  :  The list.
 *
 * Returns     :  The last node.
 *
 *********************************************************************/
struct gen_list_rec *gen_list_get_last( const struct gen_list *this_list )
{
	if ( NULL == this_list->last )
	{
		return( NULL );
	}

	/* Access to rec of gen_list_node is allowed since it is private to gen_list */
	return( this_list->last->rec );

}


/*********************************************************************
 *
 * Function    :  gen_list_insert
 *
 * Description :  Inserts a record into the list.  This is the
 *						primary API interface for inserting a record.
 *
 * Parameters  :
 *          1  :  The list.
 *          2  :  A new record to insert into the list.
 *
 * Returns     :  The node.
 *
 *********************************************************************/
const struct gen_list_node *gen_list_insert( struct gen_list *this_list, struct gen_list_rec *_rec )
{
	return( gen_list_insert_node( this_list, gen_list_node_construct( _rec ) ) );

}


/*********************************************************************
 *
 * Function    :  gen_list_stream
 *
 * Description :  Displays all attributes on the STDOUT stream,
 *						including the contents of the nodes.
 *
 * Parameters  :
 *          1  :  The list.
 *
 * Returns     :  The list.
 *
 *********************************************************************/
const struct gen_list *gen_list_stream( const struct gen_list *this_list )
{
	const struct gen_list_node *curr = this_list->first;

	LIST_SHOW( printf( "\
stream this_list\t\t\t= %p
stream this_list->first\t= %p
stream this_list->last\t= %p\n\n", (const void *)this_list, (const void *)this_list->first, (const void *)this_list->last ) );

	while ( NULL != curr )
	{
		struct gen_list_node	*next = gen_list_node_get_next( curr );
		gen_list_node_stream( curr );
		curr = next;
	}

	return( this_list );

}


/*********************************************************************
 *
 * Function    :  gen_list_equal
 *
 * Description :  Compares two lists (and their nodes) to see if they are equal.
 *
 * Parameters  :
 *          1  :  A list.
 *          2  :  Another list.
 *
 * Returns     :  0 => NOT EQUAL, anything else is EQUAL.
 *
 *********************************************************************/
int gen_list_equal( const struct gen_list *this_list, const struct gen_list *eq_list )
{
	struct gen_list_node *c1 = this_list->first;
	struct gen_list_node *c2 = eq_list->first;
	int eq = 1;

	if ( ( NULL == c1 && NULL != c2 ) || ( NULL != c1 && NULL == c2 ) )
	{
		return( 0 );
	}

	while ( ( eq ) && ( NULL != c1 ) && ( NULL != c2 ) )
	{
		/* Access to rec of gen_list_node is allowed since it is private to gen_list */
		eq = CALL_VT_REC_EQUAL( c1->rec, c2->rec );
		if ( NULL != c1 )
		{
			c1 = gen_list_node_get_next( c1 );
		}

		if ( NULL != c2 )
		{
			c2 = gen_list_node_get_next( c2 );
		}

	}

	if ( NULL == c1 && NULL == c2 )
	{
		return( 1 );
	}

	return( eq );

}


/*********************************************************************
 *
 * Function    :  gen_list_find
 *
 * Description :  Find a record that matches the one passed to this
 *						function.
 *						NOTE: this function receives a RECORD and not a NODE.
 *						Some implementation issues might be easier addressed
 *						if a node was passed ... but for the time being, I
 *						would like to keep the use/programmer isolated from
 *						the node structure/class.